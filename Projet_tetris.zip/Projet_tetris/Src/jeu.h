#ifndef JEU_H
#define JEU_H

void tetris_setup();
void jeu_init();
void test_ajout();
void t_color();	
int move(int);
void draw_tetrimono(int,int);
void erase_tetriono(int,int);
//void rotate_tetrimono(int,int);
//void move_right(int,int);
//void move_left(int,int);
int ligne_haut();
int ligne_bas();
void nouvelle_piece();
void efface_ligne(int);
void dessine_ligne(int);

#endif /* JEU_H */

/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_hal.h"
#include "gpio.h"
#include "LCD.h"
#include "glcdfont.h"
#include "shapes.h"
#include "tetris.h"
#include "stdlib.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
volatile int l,c,cx,cy,inte,b,r,vitesse,timer,up,down,num,fin,m; // b block r rotations 
volatile int zone_jeu[TETRIS_V][TETRIS_H][2];
volatile int score, nb_lignes,level, best_s,nb_l_sup;
static int t=0; //Pour le timer

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void tetris_setup();
void jeu_init();
void draw_tetrimono();
//void rotate_tetrimono(int,int);
//void move_right(int,int);
//void move_left(int,int);
int ligne_haut();
int ligne_bas();
//void efface_ligne(int);
//void dessine_ligne(int);
void points();

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
void HAL_SYSTICK_Callback(void);

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
/* USER CODE END 0 */

int main(void)
{
	volatile int arret=0;
	int i,j,k,s,test,col;
	int droite,gauche;
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */
  /* MCU Configuration----------------------------------------------------------*/
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
  /* Configure the system clock */
  SystemClock_Config();
  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */
  /* Initialize all configured peripherals */
  MX_GPIO_Init();
	LCD_Begin();

  /* USER CODE BEGIN 2 */
	//Parametres du lcd
	LCD_FillScreen(BLACK);
	LCD_SetTextSize(2);
	LCD_SetTextColor(WHITE,BLACK);
	LCD_SetCursor(1,20);
	cx=110;cy=100;
	
	//Espace de jeu
	tetris_setup();
	cx=110;cy=100;
	inte =0; timer =0;
	vitesse =1000;
	best_s=0;
  /* USER CODE END 2 */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)                    //Pour jouer plusieurs parties
	{
		//Initialisation du jeu
		jeu_init();
		while(fin==0){						//Tant qu'on a pas gameover
			//on cree une piece
			b=(rand()%7);						//b type de piece
			r=0;										//Rotation
			up=ligne_haut();
			down=ligne_bas();
			
			//est-ce qu'on peut l'ajouter au tableau?
			for(i=0;i<SIZE-up-down;i++){
				for(j=0;j<SIZE;j++){
					if(PIECES[b][r][i+up][j]==0){}
					else{
						if(zone_jeu[0+i][4+j][0]==0){}
						else{fin=1;}
					} 
				}
			}
			
			//Oui, on lui attribue une couleur et un numero et on la met dans le tableau
			if(fin==0){
				num++;
				for(i=0;i<SIZE-up-down;i++){
					for(j=0;j<SIZE;j++){
						if(PIECES[b][r][i+up][j]==0){}
						else{
							zone_jeu[0+i][4+j][0]=b+1;
							zone_jeu[0+i][4+j][1]=num;
						} 
					}
				}
			}
			//Affichage a faire en fonction de la zone de jeu
			draw_tetrimono();
			arret=0;
			//Non Game over
			while(arret==0){				//Tant que la piece peut descendre
				//La piece descend
				if(timer==1){
					for(j=0;j>12;j++){
						if(zone_jeu[17][j][1]==num)
							arret=1;
					}
					if(arret==0){
						for(i=16;i>=0;i--){
							for(j=0;j<12;j++){
								if(zone_jeu[i][j][1]==num){
									if(zone_jeu[i+1][j][0]==0){}
									else{arret=1;}	
								}
							}
							if(arret==0){
								for(j=0;j<12;j++){
									if(zone_jeu[i][j][1]==num){
										zone_jeu[i+1][j][0]=zone_jeu[i][j][0];
										zone_jeu[i+1][j][1]=zone_jeu[i][j][1];
										zone_jeu[i][j][0]=0;
										zone_jeu[i][j][1]=0;
									}
								}
							}
						}
					}
					timer=0;
				}
				
				//Droite gauche
				//m=sonar
				droite=0;gauche=0;
				i=0;j=0;
				while(zone_jeu[i][j][1]!=num){
					i++;
					if(i==17){
						j++;
						i=0;
					}
				}
				//conditions d'arret A FAIRE!!!!
				//i,j coordonnes du premier num en partant de la gauche en balayant de haut en bas
				if(m<j){
					for(k=0;k<TETRIS_H;k++){
						for(s=0;s<TETRIS_V;s++){
							if(zone_jeu[s][k][1]==num){
								if(zone_jeu[s][k-1][0]==0){}
								else{droite=1;};
							}
						}
					}
					if(droite==0){
						for(k=0;k<TETRIS_H;k++){
							for(s=0;s<TETRIS_V;s++){
								if(zone_jeu[s][k][1]==num){
									zone_jeu[s][k-1][0]=zone_jeu[s][k-1][0];
									zone_jeu[s][k-1][1]=zone_jeu[s][k-1][1];
									zone_jeu[s][k][0]=0;
									zone_jeu[s][k][1]=0;
								}
							}
						}
					}
				draw_tetrimono();
				}
				else if(m>j){
					i=0;j=11;
					while(zone_jeu[i][j][1]!=num){
						i++;
						if(i==17){
							j--;
							i=0;
						}
					}
					
					for(k=TETRIS_H-1;k>=0;k--){
						for(s=0;s<TETRIS_V;s++){
							if(zone_jeu[s][k][1]==num){
								if(zone_jeu[s][k+1][0]==0){}
								else{gauche=1;};
							}
						}
					}
					if(gauche==0){
						for(k=TETRIS_H-1;k>=0;k--){
							for(s=0;s<TETRIS_V;s++){
								if(zone_jeu[s][k][1]==num){
									zone_jeu[s][k+1][0]=zone_jeu[s][k+1][0];
									zone_jeu[s][k+1][1]=zone_jeu[s][k+1][1];
									zone_jeu[s][k][0]=0;
									zone_jeu[s][k][1]=0;
								}
							}
						}
					}
				draw_tetrimono();
				}
				
				//Affichage
				draw_tetrimono();
			}
			
			//Test de ligne pleine
			test=1;
			nb_l_sup=0;
			for(i=0;i<TETRIS_V;i++){
				for(j=0;j<TETRIS_H;j++){
					test=test*zone_jeu[i][j][0];
				}
				if(test==0){}
				else{																//Ligne pleine decalage
					nb_lignes++;
					nb_l_sup++;
					for(j=0;j<TETRIS_H;j++){
						zone_jeu[i][j][0]=0;
						zone_jeu[i][j][1]=0;
						if(i!=0){
							zone_jeu[i][j][0]=zone_jeu[i-1][j][0];
							zone_jeu[i][j][1]=zone_jeu[i-1][j][1];
						}
						else{
							zone_jeu[0][j][0]=0;
							zone_jeu[0][j][1]=0;
						}
					if(zone_jeu[i][j][0]==0)
						col=BLACK;
					else if(zone_jeu[i][j][0]==1)
						col=YELLOW;
					else if(zone_jeu[i][j][0]==2)
						col=CYAN;
					else if(zone_jeu[i][j][0]==3)
						col=GREEN;
					else if(zone_jeu[i][j][0]==4)
						col=RED;
					else if(zone_jeu[i][j][0]==5)
						col=ORANGE;
					else if(zone_jeu[i][j][0]==6)
						col=BLUE;
					else
						col=PURPLE;
					points();
					LCD_DrawRect(cx+10*j,cy+10*i,10,10,col);
					}
				}
			}

			
		}
		//Game over
		//Fonction de photo 
		//Fonction restart fin=0
	}
  /* USER CODE END 3 */

}


/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Configure the main internal regulator output voltage 
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */
void HAL_SYSTICK_Callback(){
	t=t+1;
	if (t==vitesse){
		timer=1;
		t=0;
	}
}
	
void tetris_setup(){
	LCD_DrawRect(109,99,122,182,WHITE);
	LCD_DrawRect(10,50,80,50,BLUE);
	LCD_DrawRect(10,100,80,50,YELLOW);
	LCD_DrawRect(10,150,80,50,RED);
	LCD_DrawRect(10,200,80,50,GREEN);
	LCD_SetTextSize(5);
	LCD_SetCursor(30,10);
	LCD_Printf("TETRIS");
	LCD_SetTextSize(1);
	LCD_SetCursor(20,55);
	LCD_Printf("Score");
	LCD_SetCursor(30,70);
	LCD_Printf("0");
	LCD_SetCursor(20,105);
	LCD_Printf("Highscore");
	LCD_SetCursor(30,120);
	LCD_Printf("0");
	LCD_SetCursor(20,155);
	LCD_Printf("Ligne");
	LCD_SetCursor(30,170);
	LCD_Printf("0");
	LCD_SetCursor(20,205);
	LCD_Printf("Level");
	LCD_SetCursor(30,220);
	LCD_Printf("0");
}

void jeu_init(){
	int i,j,k;
	for(i=0;i<TETRIS_V;i++){		//Remise a zero du tableau
			for(j=0;j<TETRIS_H;j++){
				for(k=0;k<2;k++)
					zone_jeu[i][j][k]=0;
				LCD_DrawRect(cx+j*10,cy+i*10,10,10,BLACK);
			}
	}
	fin=0;num=0;
	score=0;nb_lignes=0;nb_l_sup=0;level=0;vitesse=1000;
}
int ligne_haut(){
	int i,j,cmt,up;
	up=0;
	cmt=0;
	for(i=0;i<SIZE;i++){
		for(j=0;j<SIZE;j++){
			if(PIECES[b][r][i][j]==0){
				cmt++;
				if(cmt==4){
					cmt=0;
					up++;
				}
			}
			else
				return(up);
		}
	}
	return(up);
}
int ligne_bas(){
	int i,j,cmt,down;
	down = 0;
	cmt=0;
	for(i=3;i>0;i--){
		for(j=0;j<SIZE;j++){
			if(PIECES[b][r][i][j]==0){
				cmt++;
				if(cmt==4){
					cmt=0;
					down++;
				}
			}
			else
				return(down);
		}
	}
	return(down);
}


void draw_tetrimono(){
	int i,j,color;
	for(i=0;i<TETRIS_V;i++){
		for(j=0;j<TETRIS_H;j++){
			if(zone_jeu[i][j][0]==0)
				LCD_DrawRect(cx+10*j,cy+10*i,10,10,BLACK);
			if(zone_jeu[i][j][1]==num){
				if(zone_jeu[i][j][0]==1)
					color=YELLOW;
				else if(zone_jeu[i][j][0]==2)
					color=CYAN;
				else if(zone_jeu[i][j][0]==3)
					color=GREEN;
				else if(zone_jeu[i][j][0]==4)
					color=RED;
				else if(zone_jeu[i][j][0]==5)
					color=ORANGE;
				else if(zone_jeu[i][j][0]==6)
					color=BLUE;
				else
					color=PURPLE;
			LCD_DrawRect(cx+10*j,cy+10*i,10,10,color);
			}
		}
	}
		HAL_Delay(10);
}




/*
void rotate_tetrimono(int nb,int r){
	erase_tetriono();
	draw_tetrimono(nb,r);
}
*/
/*
void move_right(int nb, int r){
	erase_tetriono();
	cx=cx+10;
	if(cx>=X_limit_max)
		cx = X_limit_max;
	draw_tetrimono(nb,r);
}
*/

/*
void move_left(int nb, int r){
	erase_tetriono();
	cx=cx-10;
	if(cx<=X_limit_min)
		cx = X_limit_min;
	draw_tetrimono(nb,r);
}
*/



void points(){
		level=nb_lignes%10;
	if (nb_l_sup==1)
		score = score+ 40*(level+1);
	else if (nb_l_sup==2)
		score = score+ 100*(level+1);
	else if (nb_l_sup==3)
		score = score+ 300*(level+1);
	else
		score = score+ 1200*(level+1);
	if(score>=best_s)
		best_s=score;
	vitesse=1000-100*level;
	cx=30;cy=220;
	LCD_Printf("%d",level);
	cx=30;cy=70;
	LCD_Printf("%d",score);
	cx=30;cy=120;
	LCD_Printf("%d",best_s);
	cx=110;cy=100;
	
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	HAL_Delay(7);
	if (HAL_GPIO_ReadPin(GPIOC,GPIO_Pin)==0){
		inte=1;
		if(GPIO_Pin == 256)
			c = 0;
		else if(GPIO_Pin == 512)
			c = 1;
		else if(GPIO_Pin == 1024)
			c = 2;
		else
			c = 3;
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,1);
		HAL_Delay(7);
		if( HAL_GPIO_ReadPin(GPIOC,GPIO_Pin)==1)
			l= c;
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,0);
		
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,1);
		HAL_Delay(7);
		if( HAL_GPIO_ReadPin(GPIOC,GPIO_Pin)==1)
			l= c+4;
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_13,0);
		
	
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,1);
		HAL_Delay(7);
		if( HAL_GPIO_ReadPin(GPIOC,GPIO_Pin)==1)
			l= c+8;
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14,0);
		
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,1);
		HAL_Delay(7);
		if( HAL_GPIO_ReadPin(GPIOC,GPIO_Pin)==1)
			l= c+12;
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_15,0);
		
		HAL_Delay(7);
		}
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_8);
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_9);
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_10);
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_11);
	
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

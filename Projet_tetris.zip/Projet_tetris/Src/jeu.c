#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include "stm32f4xx_hal.h"
#include "LCD.h"
#include "shapes.h"
#include "tetris.h"
#include "jeu.h"
#include "main.h"


void tetris_setup(){
	LCD_DrawRect(110,100,120,180,WHITE);
	LCD_DrawRect(10,50,80,50,BLUE);
	LCD_DrawRect(10,100,80,50,YELLOW);
	LCD_DrawRect(10,150,80,50,RED);
	LCD_DrawRect(10,200,80,80,GREEN);
	LCD_SetTextSize(5);
	LCD_SetCursor(30,10);
	LCD_Printf("TETRIS");
	LCD_SetTextSize(1);
	LCD_SetCursor(20,55);
	LCD_Printf("Score");
	LCD_SetCursor(30,70);
	LCD_Printf("0");
	LCD_SetCursor(20,105);
	LCD_Printf("Highscore");
	LCD_SetCursor(30,120);
	LCD_Printf("0");
	LCD_SetCursor(20,155);
	LCD_Printf("Ligne");
	LCD_SetCursor(30,170);
	LCD_Printf("0");
	LCD_SetCursor(20,205);
	LCD_Printf("P suivante");
}

void jeu_init(){
	int i,j;
	score=0; nb_lignes =0; level=0;
	for(i=0;i<TETRIS_H;i++){
		for(j=0;j<TETRIS_V;j++)
			zone_jeu[i][j]=0;
			LCD_DrawRect(cx+j*10,cy+i*10,10,10,BLACK);
	}
	fin =0;
}

void test_ajout(){
	int i,j;
	for(i=up;i<SIZE-down;i++){
			for(j=0;j<SIZE;j++){
				zone_jeu[i-up][j+4]=zone_jeu[i-up][j+4]+PIECES[b][r][i][j];
				if(zone_jeu[i-up][j+4]>2)
					fin=1;
				
			}
		}
}

void t_color(){
	int i,j;
	for(i=0;i<SIZE-down-up;i++){
				for(j=4;j<SIZE+4;j++){
					if(zone_jeu[i][j]==1)
						zone_jeu[i][j]=zone_jeu[i][j]*b+1;
				}
			}
}
int ligne_haut(){
	int i,j,cmt,up;
	up=0;
	for(i=0;i<SIZE;i++){
		for(j=0;j<SIZE;j++){
			if(PIECES[b][r][i][j]==0){
				cmt++;
				if(cmt==4){
					cmt=0;
					up++;
				}
			}
			else
				return(up);
		}
	}
	return(up);
}
int ligne_bas(){
	int i,j,cmt,down;
	down = 0;
	for(i=3;i>0;i--){
		for(j=0;j<SIZE;j++){
			if(PIECES[b][r][i][j]==0){
				cmt++;
				if(cmt==4){
					cmt=0;
					down++;
				}
			}
			else
				return(down);
		}
	}
	return(down);
}

void draw_tetrimono(int x,int y){
	int i,j,color;
	for(i=0;i<SIZE-up-down;i++){
		for(j=0;j<SIZE;j++){
			if(zone_jeu[i][j]==0){
				}
			else {
				if(zone_jeu[i][j]==1)
					color=YELLOW;
				else if(zone_jeu[i][j]==2)
					color=CYAN;
				else if(zone_jeu[i][j]==3)
					color=GREEN;
				else if(zone_jeu[i][j]==4)
					color=RED;
				else if(zone_jeu[i][j]==5)
					color=ORANGE;
				else if(zone_jeu[i][j]==6)
					color=BLUE;
				else
					color=PURPLE;
				LCD_DrawRect(y+i*10,x+10*j,10,10,color);

			}
		}
	}
		HAL_Delay(10);
}


void erase_tetriono(int x, int y){
	int i,j;
	for(i=0;i<SIZE-up-down;i++){
		for(j=0;j<SIZE;j++)
				LCD_DrawRect(y+i*10,x+10*j,10,10,BLACK);
		}
	}


/*
void rotate_tetrimono(int nb,int r){
	erase_tetriono();
	draw_tetrimono(nb,r);
}
*/
/*
void move_right(int nb, int r){
	erase_tetriono();
	cx=cx+10;
	if(cx>=X_limit_max)
		cx = X_limit_max;
	draw_tetrimono(nb,r);
}
*/

/*
void move_left(int nb, int r){
	erase_tetriono();
	cx=cx-10;
	if(cx<=X_limit_min)
		cx = X_limit_min;
	draw_tetrimono(nb,r);
}
*/

void nouvelle_piece(){
		b=rand()%7;
		r=0;
	
		d.Type=b;
		if(b==0)
			d.color=YELLOW;
		else if(b==1)
			d.color=CYAN;
		else if(b==2)
			d.color=GREEN;
		else if(b==3)
			d.color=RED;
		else if(b==4)
			d.color=ORANGE;
		else if(b==5)
			d.color=BLUE;
		else
			d.color=PURPLE;
		
		d.rotation=r;
		d.X=4;
		d.Y=0;	
}

void efface_ligne(int i){
	int j,color;
	for(j=0;j<TETRIS_H;j++)
		LCD_DrawRect(10*j,i,10,10,BLACK);
	
}
void dessine_ligne(int i){
	int j,color;
	for(j=0;j<TETRIS_H;j++){
		if(zone_jeu[i][j]==1)
					color=YELLOW;
				else if(zone_jeu[i][j]==2)
					color=CYAN;
				else if(zone_jeu[i][j]==3)
					color=GREEN;
				else if(zone_jeu[i][j]==4)
					color=RED;
				else if(zone_jeu[i][j]==5)
					color=ORANGE;
				else if(zone_jeu[i][j]==6)
					color=BLUE;
				else if(zone_jeu[i][j]==0)
					color=BLACK;
				else
					color=PURPLE;
		LCD_DrawRect(cx+10*j,cy+i,10,10,color);
		
	}
	cx=110;cy=100;
	LCD_DrawRect(cx,cy,120,10,BLACK);
}